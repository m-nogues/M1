<?php
session_start();
include_once "../classes/mymodel.php";
$id=$_GET['id'];
if ($_SESSION["reussi"] != "yes")
{
	header('Location: ../auth.php');
}
?>
<html>
<head>

	<link rel="stylesheet" type="text/css" href="../CSS/pagePrinc.css" />
    <title>Site</title>
</head>
<body background="../Images/background.jpg">
<?php
echo "<div class=\"gauche\"><a href=./logout.php>Deconnexion</a><br><br /><br />";
echo "<a href=./ajoutCommentaire.php?id=".$id.">Ajout comentaire</a><br />";
echo "<a href=./afficherMesInfos.php?id=".$id.">Afficher mes infos</a><br />";
echo "<a href=./ajoutFichier.php?id=".$id.">Upload fichier</a></div>";
?>
</body>
<div class=centre>Ajouter un commentaire:
<?php echo "<form action=\"./ajoutcom.php\"".$id." method=\"post\">";?>
    <div>
        <label for="message">Message :</label>
   <?php echo "     <input type=\"hidden\"  name=\"id\" id=\"id\" value=\"".$id."\">";?>
        <textarea row="10" cols="50" id="toto" name="toto"></textarea>
        <div class="button">
            <button type="submit">Envoyer votre message</button>
        </div>
    </div>
</form></div>
</html>
