<?php
session_start();
include_once "../classes/Commentaires.php";
include_once "../classes/ClasseUsers.php";
$com=new Commentaires();
$user=new Users();
$com2=$_POST["toto"];
$id=$_POST["id"];
if ($_SESSION["reussi"] == "no")
{
	echo "<div id=\"prb\" class=\"prb\">Login ou mot de passe incorrect !!!!!!!</div>";
}
    $nom = $user->getNom($id);
    $ligne = $user->fetch($nom);
    $coms = $com->insertion($ligne["Nom"],$com2);
    echo "Insertion faite";
    echo "<form enctype=multipart/form-data action=\"./welcome.php?id=".$id."\" method=\"post\">";
    echo "<input type=\"submit\">Valider.</submit>";
    echo "</form>";
?>
