<?php
session_start();
include_once "../classes/Commentaires.php";
include_once "../classes/ClasseUsers.php";
$com=new Commentaires();
$user=new Users();
$champs=$_POST["lenom"];
$id=$_POST["id"];
$nom=$_POST["nom"];
if (isset($_SESSION["reussi"])){
if ($_SESSION["reussi"] != "yes")
{
	header('Location: ../auth.php');
}
}
$champ="";
    foreach ($champs as $value){
        $champ.=$value.",";
    }
    $champ=substr($champ,0,-1);
    $noms = $user->getInfosUser($champ,$nom);
    $ligne = $user->fetch($noms);
?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="../CSS/pagePrinc.css" />
    <title>Site</title>
</head>
<body background="../Images/background.jpg">
<?php

echo "<div class=\"menugauche\"><a href=./logout.php>Deconnexion</a><br><br />";
echo "<a href=./ajoutCommentaire.php?id=".$id.">Ajout comentaire</a><br />";
echo "<a href=./afficherMesInfos.php?id=".$id.">Afficher mes infos</a><br />";
echo "<a href=./ajoutFichier.php?id=".$id.">Upload fichier</a></div>";


echo "<div class=\"centre\">";
        echo "Les infos de $nom: ";
        foreach($ligne as $l)
        {
            echo $l."<br/>";
	}

	        echo "<FORM enctype=multipart/form-data action=\"./afficherMesInfos.php?id=$id\" method=\"post\">";
            echo "<input type=\"submit\" value=\"Valider\">";
            echo "</FORM>";
 ?>
</div>
</body>
</html>
