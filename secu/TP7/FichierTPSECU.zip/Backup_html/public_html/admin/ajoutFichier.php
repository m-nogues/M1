<?php
session_start();
include_once "../classes/mymodel.php";
$id=$_GET['id'];
if ($_SESSION["reussi"] != "yes")
{
	header('Location: ../auth.php');
}
?>



<html>
<head>
	<link rel="stylesheet" type="text/css" href="../CSS/Ajouter_photo.css" />
    <title>Site</title>
</head>
 
<body background="../Images/background.jpg">
<?php

echo "<div class=\"menugauche\"><a href=./logout.php>Deconnexion</a><br><br /><br />";
echo "<div><a href=./ajoutCommentaire.php>Ajout comentaire</a></div><br /><br /><br />";
echo "<a href=./afficherMesInfos.php?id=".$id.">Afficher mes infos</a><br />";
echo "<div class=\"gauche\"><a href=./afficherMesInfos.php?id=".$id.">Afficher mes infos</a></div>";
?>


<!--Div de Droite-->
<div class="centre">
<form enctype=multipart/form-data action="upload.php" method="post">
<?php echo "<input type=\"hidden\" name=\"id\" value=\"".$id."\">";?>
      Fichier <input type="file" name="file" />
      <input type="submit" />
    </form>



<!--     Fichier : <input type=\"file\" id=\"avatar\" name=\"avatar\">";
     <input type=\"submit\" name=\"envoyer\" value=\"Envoyer le fichier\"></p>";
</form>";-->
</div>
<!--<input type="submit" name="submit" value="Submit">
</form>-->

<!--Fin Div de droite-->
<!--Fin du DIV-->
</form>
</body>
</html>
