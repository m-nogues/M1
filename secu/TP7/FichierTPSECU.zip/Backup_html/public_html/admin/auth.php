<?php
session_start();
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0//EN" "TBD">
<html>
<head>
<title>Identification</title>
<script langage="javascript">
function connec()
{
	document.location.href="controlAuth.php";
}
</script>
<link rel="stylesheet" type='text/css'href='../CSS/auth.css'>
</head>
<body background="../Images/Admin/admin.jpg">
<form name="auth" method="POST" action="controlAuth.php">
<br/><br/><br/>
<?php
if ($_SESSION["reussi"] == "no")
{
	echo "<div id=\"prb\" class=\"prb\">Login ou mot de passe incorrect !!!!!!!</div>";
}
else
{
	echo "<br/>";
}
?>
<br/><br/><br/><br/>

<div class="auth" background="../Images/Admin/fond.gif">
<br/><br/>
&nbsp;&nbsp;&nbsp;Login : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="login" name="login"/><br/>
&nbsp;&nbsp;&nbsp;Mot de passe : <input type=password id="mdp" name="mdp"/><br/>
<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit"/>
<br/><br/><br/>
</div>
</form>
</body>
</html>
	
	
	
