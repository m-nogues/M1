<?php
session_start();
?>

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0//EN" "TBD">

<html>
<head>
	<link rel="stylesheet" type="text/css" href="../CSS/pagePrinc.css" />
    <title>Site</title>
<?php
if ($_SESSION["reussi"] == "no")
{
	echo "<div id=\"prb\" class=\"prb\">Login ou mot de passe incorrect !!!!!!!</div>";
}
else
{
	echo "<br/>";
}
?>

</head>
    <body background="../Images/background.jpg">

        <div class="titre"><h1> Bienvenu sur notre nouveau site</h1></div>

        <div class="login">
          <h1>Identification</h1>
          <form method="POST" action="verif.php">
            <p><input type="text" id="login" name="login" value="" placeholder="Username or Email"></p>
            <p><input type="password" id="password" name="password" value="" placeholder="Password"></p>
            <p class="submit"><input type="submit"/></p>
          </form>
        </div>


    </body>
</html>
