<?php
session_start();
include_once "../classes/mymodel.php";
include_once "../classes/ClasseUsers.php";
$users = new Users();
$id=$_GET['id'];
$chemin = $_GET['file'];
if (isset($_SESSION["reussi"])){
if ($_SESSION["reussi"] != "yes")
{
	header('Location: ../auth.php');
}
}
?>
<html>
<head>

	<link rel="stylesheet" type="text/css" href="../CSS/pagePrinc.css" />
    <title>Site</title>
</head>
<body background="../Images/background.jpg">
<?php

echo "<div class=\"menugauche\"><a href=./logout.php>Deconnexion</a><br><br />";
echo "<a href=./ajoutCommentaire.php?id=".$id.">Ajout comentaire</a><br />";
echo "<a href=./ajoutFichier.php?id=".$id.">Upload fichier</a></div>";


echo "<div class=\"centre\">";
        echo "Mes infos:<br /><br />";
        $user = $users->getUser($id);
        $ligne = $users->fetch($user);
        while($ligne)
        {
            if(!empty($ligne['id']))
            {
	            echo "Id :".$ligne['id']."<br />";
	        }
	        if(!empty($ligne['Nom']))
            {    
	            echo "Nom :".$ligne['Nom']."<br />";
	        }
	        if(!empty($ligne['Prenom']))
            {
	            echo "Prenom :".$ligne['Prenom']."<br />";
	        }
	        if(!empty($ligne['Rue']))
            {
	            echo "Rue :".$ligne['Rue']."<br />";
	        }
	        if(!empty($ligne['CP']))
            {
	            echo "CP :".$ligne['CP']."<br />";
	        }
	        if(!empty($ligne['Ville']))
            {
	            echo "Ville :".$ligne['Ville']."<br />";
	        }
	        if(!empty($chemin))
	        {
	            echo "<img src=\"../".$chemin."\" border=\"0\" align=\"center\" width=100 height=100/>";
	        }
	        
	        //if(!empty($ligne['CB']))
               //{
	         //   echo "CB ".$ligne['CB']."<br />";
	        //}
	        $ligne = $users->fetch($user);
	    }

            echo "<br/><br/>Choisir les infos a afficher sur un utilisateur:";
	        
	        
	        echo "<FORM enctype=multipart/form-data action=\"./affInfoUser.php\" method=\"post\">";
	        echo "entrer le nom de l'utilisateur";
	        echo "<input type=\"text\" value=\"Exemple\" id=\"nom\" name=\"nom\" /> <br/>";
	        echo "     <input type=\"hidden\"  name=\"id\" id=\"id\" value=\"".$id."\">";
            echo "    <select name=\"lenom[]\" multiple=\"multiple\" size=\"10\">";
            echo "        <OPTION>Nom";
            echo "        <OPTION>Prenom";
            echo "        <OPTION>Rue";
            echo "        <OPTION>CP";
            echo "        <OPTION>Ville";
            echo "    </SELECT>";
            echo "<input type=\"submit\" value=\"Valider\"/>";
            echo "</FORM>";
            
            
 ?>
</div>
</body>
</html>
