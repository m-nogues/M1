<?php
session_start();
include_once "../classes/mymodel.php";
include_once "../classes/ClasseUsers.php";
$id=$_GET['id'];
if (isset($_SESSION["reussi"])){
if ($_SESSION["reussi"] != "yes")
{
	header('Location: ../auth.php');
}
}
?>
<html>
<head>

	<link rel="stylesheet" type="text/css" href="../CSS/pagePrinc.css" />
    <title>Site</title>
</head>
<body background="../Images/background.jpg">

<?php

$users = new Users();

$user = $users->getUserBis($id);

$ligne = $users->fetch($user);




while($ligne)
{
	if(!empty($ligne['Nom']))
	{
	    $nom= $ligne['Nom'];
	}
	if(!empty($ligne['Chemin']))
	{
	
	    $chemin = $ligne['Chemin'];
	}
	$ligne = $users->fetch($user);
}


if(!empty($nom))
{
	echo "Bienvenue Mr. $nom   ";
}
if(!empty($chemin))
{
    echo "<img src=\"../".$chemin."\" border=\"0\" align=\"center\" width=100 height=100/>";
}


echo "<br /><br /><a href=./logout.php>Deconnexion</a><br /><br /><br />";
echo "<a href=./ajoutCommentaire.php?id=".$id.">Ajout comentaire</a><br />";
echo "<a href=./ajoutFichier.php?id=".$id.">Upload fichier</a><br />";

if(!empty($chemin))
{
    echo "<a href=./afficherMesInfos.php?id=".$id."&file=".$chemin.">Afficher mes infos</a></div>";
}
else
{
    echo "<a href=./afficherMesInfos.php?id=".$id.">Afficher mes infos</a><br /></div>";
}

?>

</body>

</html>
