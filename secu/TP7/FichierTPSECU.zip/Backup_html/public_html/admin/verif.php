<?php
session_start();
include_once "../classes/mymodel.php";

try {
    
    $login = $_POST["login"];
    $mdp = $_POST["password"];
  
    $req = "select id,Nom, Mdp from Users where Nom=\"".$login."\" and Mdp=\"".$mdp."\" limit 1;";
    $db = new mysqli_();
    $db->connect("site", "db", "azerty");
    

    $result = $db->query($req);
    $resultat = $db->fetch($result);
    $id=$resultat['id'];

    echo $id;
    

    if(!(empty($resultat['Nom'])))
    {
	    $_SESSION['reussi'] = "yes" ;
	    $url = "./welcome.php?id=".$id;
	    header("Location:".$url);
    }
    else
    {
	    $_SESSION['reussi'] = "no" ; 
	    header('Location: index.php');	
    }
}
catch(Exception $e)
{
	//echo $req;
     $e->getMessage();
     $_SESSION['reussi'] = "no" ; 
	 header('Location: index.php');	
}
?>

