
<?php
include_once "../classes/ClasseUsers.php";
$users = new Users();
$id=$_POST['id'];



     $dossier = '../Uploader/';
     $fichier = basename($_FILES['file']['name']);
echo $dossier . $fichier;
     if(move_uploaded_file($_FILES['file']['tmp_name'], $dossier . $fichier)) //Si la fonction renvoie TRUE, c'est que �a a fonctionn�...
     {
        $chemin = "\"Uploader/".$_FILES['file']['name']."\"";
        $user = $users->insertPhoto($id,$chemin);
          echo 'Upload effectu� avec succ�s !';
          
          echo "<form enctype=multipart/form-data action=\"./welcome.php?id=".$id."\" method=\"post\">";
          echo "<input type=\"submit\" value=\"Valider\" />";
          echo "</form>";
          
     }
     else //Sinon (la fonction renvoie FALSE).
     {
          echo 'Echec de l\'upload !';
          echo "<form enctype=multipart/form-data action=\"./welcome.php?id=".$id."\" method=\"post\">";
          echo "<input type=\"submit\" value=\"Valider\" />";
          echo "</form>";
     }

?>
