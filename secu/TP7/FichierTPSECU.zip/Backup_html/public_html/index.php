<?php
session_start();
include_once "./classes/Commentaires.php";
$com=new Commentaires();
?>

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0//EN" "TBD">

<html>
<head>
	<link rel="stylesheet" type="text/css" href="./CSS/pagePrinc.css" />
    <title>Site</title>
<?php
if (isset($_SESSION["reussi"])){
if ($_SESSION["reussi"] != "yes")
{
	header('Location: ../auth.php');
}
}
else
{
	echo "<br/>";
}
?>

</head>
    <body background="./Images/background.jpg">

        <div class="titre"><h1>Audit de code php</h1></div><br\>
        Ne surtout pas utiliser le code de se site tel quel!! de nombreuses failles sont présentes!!!<br\><br\>
        <div class="index"> Pour deposer un commentaire vous devez vous authentifier. </div>
        <div class="menugauche"><a href=./admin/index.php>Connexion</a></div>
        <div class="left"><br\>Commentaires:</div>
        <div class="centre">
        <?php
            $coms = $com->getCom();
            
		    $ligne = $com->fetch($coms);
		    while($ligne)
		    {
		        echo "<table width=\"100%\" border=\"1\" cellspacing=\"1\" cellpadding=\"1\"><tr><td><div align=center>Commentaire de:".$ligne['Login']." -- ".$ligne['Commentaire']."</div></td><tr></table>";
			    $ligne = $com->fetch($coms);
		    }
        ?>
        </div>
    </body>
</html>
