<?php
session_start();
include_once "../classes/mymodel.php";
include_once "../classes/ClasseUsers.php";
$users = new Users();
$id=$_GET['id'];
if ($_SESSION["reussi"] != "yes")
{
	header('Location: ../auth.php');
}

?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../CSS/pagePrinc.css" />
    <title>Site</title>
</head>
<body background="../Images/background.jpg">
<?php

echo "<div class=\"menugauche\"><a href=./logout.php>Deconnexion</a><br><br />";
echo "<a href=./ajoutCommentaire.php?id=".$id.">Ajout comentaire</a><br />";
echo "<a href=./afficherMesCommentaires.php?id=".$id.">Ajout comentaire</a><br />";
echo "<a href=./ajoutFichier.php?id=".$id.">Upload fichier</a></div>";


echo "<div class=\"centre\">";
    
        $user = $users->getUser($id);
        $ligne = $users->fetch($user);
        while($ligne)
        {
            if(!empty($ligne['id']))
            {
	            echo "Id ".$ligne['id']."<br />";
	        }
	        if(!empty($ligne['Nom']))
            {    
	            echo "Nom ".$ligne['Nom']."<br />";
	        }
	        if(!empty($ligne['Prenom']))
            {
	            echo "Prenom ".$ligne['Prenom']."<br />";
	        }
	        if(!empty($ligne['Rue']))
            {
	            echo "Rue ".$ligne['Rue']."<br />";
	        }
	        if(!empty($ligne['CP']))
            {
	            echo "CP ".$ligne['CP']."<br />";
	        }
	        if(!empty($ligne['Ville']))
            {
	            echo "Ville ".$ligne['Ville']."<br />";
	        }
	        if(!empty($ligne['CB']))
            {
	            echo "CB ".$ligne['CB']."<br />";
	        }
	        
	        $ligne = $users->fetch($user);
	    }
    ?>
</div>
</body>
</html>
