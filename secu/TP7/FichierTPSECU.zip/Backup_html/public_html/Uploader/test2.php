<?php
include_once "mymodel.php";

class Users {

	var $user = "db";
	var $passwd = "azerty";	
	var $host = "localhost";
	var $bdd = "site";
	
	public function __Construct()
	{
		$this->db = new mysqli_();
		$this->db->connect($this->bdd, $this->user, $this->passwd);
	}

	
	function fetch(mysqli_result $req)
	{
		return $this->db->fetch($req);
	}
	
	function insertion($nom, $prenon, $rue, $cp, $ville, $cb, $mdp)
	{
		$req = "insert into Users value (\"\",$nom, $prenon, $rue, $cp, $ville, $cb, $mdp);";
		$result = $this->db->query($req);
		return $result;
	}
	function getUser($id)
    {
	    $req = "SELECT id, Nom,Prenom,Rue,CP,Ville,CB,Mdp FROM Users where id=$id ;";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    function getAllUsers()
    {
    	$req = "SELECT id, Nom,Prenom,Rue,CP,Ville,CB,Mdp FROM Users ;";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    function getInfos($id)
    {
    	$req = "SELECT id, Nom,Prenom,Rue,CP,Ville,CB,Mdp FROM Users ;";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    function getNom($id)
    {
    	$req = "SELECT Nom FROM Users where id=".$id.";";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    
}
?>

