<?php
class mysqli_{
	public $Host = 'localhost';
	public $user;
	public $password;
	public $base;
	protected $dbo;
	
		public function connect ($Base,$User,$Password) {
		$this->dbo = new mysqli($this->Host, $User, $Password, $Base);
		$this->user=$User;
		$this->password=$Password;
		$this->base=$Base;
		
	}

	public function deconnect() {
		$this->dbo->close();
		
	}


	public function query ($query) {
		if (!$Result=$this->dbo->query($query)){
			throw new Exception('query'.$this->Error());
		}else{
			return $Result;
		}
	}
	
	public function arrayQuery ($query) {
		if (!$Result=$this->dbo->query($query)){
			throw new Exception('arrayQuery ::'.$this->Error());
		}else{
		$R= array();
		while ($data=$Result -> fetch_assoc()){
			$R[]=$data;
		}
		return $R;
	}
	}
	public function fetch(mysqli_result $result) {
		return $result->fetch_assoc();
			
	}
	public function error() {
		return $this->dbo->error;

	}
}


