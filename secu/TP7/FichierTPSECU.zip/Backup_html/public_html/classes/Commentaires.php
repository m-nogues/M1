<?php
include_once "mymodel.php";

class Commentaires {

	var $user = "db";
	var $passwd = "azerty";	
	var $host = "localhost";
	var $bdd = "site";
	
	public function __Construct()
	{
		$this->db = new mysqli_();
		$this->db->connect($this->bdd, $this->user, $this->passwd);
	}

	
	function fetch(mysqli_result $req)
	{
		return $this->db->fetch($req);
	}
	
	function insertion($nom,$commentaire)
	{
		$req = "insert into Commentaire value (\"\",\"$nom\",\" $commentaire\");";
		$result = $this->db->query($req);
		return $result;
	}
	function getCom()
    {
	    $req = "SELECT Login, Commentaire FROM Commentaire;";
	    $result = $this->db->query($req);
	    return $result;
    }
    
}
?>
