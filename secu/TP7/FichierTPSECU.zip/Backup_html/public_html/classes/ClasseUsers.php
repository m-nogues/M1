<?php
include_once "mymodel.php";

class Users {

	var $user = "db";
	var $passwd = "azerty";	
	var $host = "localhost";
	var $bdd = "site";
	
	public function __Construct()
	{
		$this->db = new mysqli_();
		$this->db->connect($this->bdd, $this->user, $this->passwd);
	}

	
	function fetch(mysqli_result $req)
	{
		return $this->db->fetch($req);
	}
	
	function insertion($nom, $prenon, $rue, $cp, $ville, $cb, $mdp, $chemin)
	{
		$req = "insert into Users value (\"\",$nom, $prenon, $rue, $cp, $ville, $cb, $mdp, $chemin);";
		$result = $this->db->query($req);
		return $result;
	}
    function getUser($id)
    {
	    $req = "SELECT id, Nom,Prenom,Rue,CP,Ville,CB,Mdp,Chemin FROM Users where id=$id ;";
	    $result = $this->db->query($req);
	    return $result;
    }

    function getUserBis($id)
    {
	    $req = "SELECT Nom,Chemin FROM Users where id=$id ;";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    function insertPhoto($id,$chemin)
    {
	    $req = "UPDATE Users SET Chemin=$chemin where id=$id ;";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    function getAllUsers()
    {
    	$req = "SELECT id, Nom,Prenom,Rue,CP,Ville,CB,Mdp FROM Users ;";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    function getInfos($id)
    {
    	$req = "SELECT id, Nom,Prenom,Rue,CP,Ville,CB,Mdp FROM Users ;";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    function getInfosUser($champs,$nom)
    {
    	$req = "SELECT $champs FROM Users where Nom=\"$nom\" ;";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    function getNom($id)
    {
    	$req = "SELECT Nom FROM Users where id=".$id.";";
	    $result = $this->db->query($req);
	    return $result;
    }
    
    
}
?>
